package com.example.food2go.ui.home;

import android.app.Fragment;

public class HomeSecondFragment extends Fragment {
}
