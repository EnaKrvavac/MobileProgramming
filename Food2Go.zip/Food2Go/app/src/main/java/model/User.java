package model;

import android.os.Build;

import androidx.annotation.RequiresApi;

import com.google.firebase.database.GenericTypeIndicator;

import java.security.cert.Extension;
import java.time.Month;
import java.util.List;

@RequiresApi(api = Build.VERSION_CODES.O)
public class User<password> {
    private String Name;
    private String Password;
    private String Phone;

    public User() {

    }

    public User(String name, String password) {
        Name = name;
        Password = password;

    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }


    public String getPassword() {
        return Password;
    }


    public void setPassword(String password) {
        Password = password;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    GenericTypeIndicator<List<User>> t = new GenericTypeIndicator<List<User>>() {};
    List<User> users;
        }