package common;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.net.ConnectivityManager;

import model.User;

public class Common {
    public static User currentUser;

         }
